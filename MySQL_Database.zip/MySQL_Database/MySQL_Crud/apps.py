from django.apps import AppConfig


class MysqlCrudConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'MySQL_Crud'
